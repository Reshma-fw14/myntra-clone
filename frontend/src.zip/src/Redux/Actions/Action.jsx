export const addKurti=(kurti)=>{
  return{
      type:"ADD-KURTI",
      payload:kurti
  }
}

export const addShirt=(kurti)=>{
    return{
        type:"ADD-SHIRT",
        payload:kurti
    }
  }

export const addGirlDress=(dress)=>{
return{
    type:"ADD-Girl-Dress",
    payload:dress
}
}