import { addKurtiReducer } from "./Reducer";
import {combineReducers} from "redux";

export const Reducers=combineReducers({
    addKurtiReducer
})